BACK UP ANY FILES IF YOU WANT TO CONSIDER ROLLBACK IN CASE OF NOT BEING SATISFIED!
or dont cuz we ball.


 (Appdata Local) folder
in windows explorer directory, type in %localappdata% and hit enter.
paste the IntoTheRadius2 folder in here.


 (Documents My Games) folder
in windows explorer directory, type in Documents and hit enter.
you will likely see a couple folders and one of them titled My Games, place the IntoTheRadius2 folder you find here, into the My Games folder.


 (ITR2 Content) folder
navigate through your steam files to your game files and place the IniSettings folder into IntoTheRadius2\IntoTheRadius2\Content\ITR2\





OpenVR RSF performance boost
download the desktop app on github : https://github.com/tappi287/openvr_fsr_app/releases/tag/0.9.9


open the app (it might open in your browser as a tab), you should find your steam library already scanned on the list, and IntoTheRadius2 as an option.


(RSF STEP 1 IMAGE)
open the drop-down menu for IntoTheRadius2 and select "VrPerfKit RSF Install plugin" option.


(RSF STEP 2 IMAGE)
carefully copy down every setting in this image onto your settings, dont miss a thing.
you can set the fps target to your max fps yada yada, adapt it to your liking since not much can go wrong, the most important thing is Hidden Mask options.

your preference if you want to squeeze extra fps with upscaling, dont go below 70% and not higher than 100%, same thing for sharpening.